package edu.mx.utez.examenrecuperacion.model.dto;

import jakarta.persistence.Column;
import lombok.*;

@Builder
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class Dtoclientes {
    private Integer id_cliente;
    private String nombre;
    private String apellido;
    private String apellido2;
    private String direccion;
    private String telefono;
}
