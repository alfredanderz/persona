package edu.mx.utez.examenrecuperacion.model.dao;
import edu.mx.utez.examenrecuperacion.model.entity.Beanuser;
import org.springframework.data.repository.CrudRepository;

public interface Daouser extends CrudRepository<Beanuser, Integer> {
}
