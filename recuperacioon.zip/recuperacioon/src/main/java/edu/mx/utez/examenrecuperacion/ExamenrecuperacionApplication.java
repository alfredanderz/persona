package edu.mx.utez.examenrecuperacion;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExamenrecuperacionApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExamenrecuperacionApplication.class, args);
	}

}
