package edu.mx.utez.examenrecuperacion.model.dto;

import lombok.*;

@AllArgsConstructor
@NoArgsConstructor
@Builder
@Getter
@Setter
public class Dtouser {
    private Integer iduser;
    private String Username;
    private Boolean Estatus;
    private String Password;
}
