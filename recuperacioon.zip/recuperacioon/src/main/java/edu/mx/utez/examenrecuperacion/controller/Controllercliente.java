package edu.mx.utez.examenrecuperacion.controller;

import edu.mx.utez.examenrecuperacion.service.impl.ClientesImpl;
import edu.mx.utez.examenrecuperacion.model.dto.Dtoclientes;
import edu.mx.utez.examenrecuperacion.model.entity.Beanclientes;
import lombok.AllArgsConstructor;
import org.springframework.dao.DataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
@AllArgsConstructor
@RestController

@RequestMapping("/api/v2")
public class Controllercliente {

    private final ClientesImpl clienteService;

    @PostMapping("/cliente")
    public Dtoclientes create(@RequestBody Dtoclientes dtocliente){
        Beanclientes clienteSave = clienteService.save(dtocliente);
        return dtocliente.builder()
                .id_cliente(dtocliente.getId_cliente())
                .nombre(dtocliente.getNombre())
                .apellido(dtocliente.getApellido())
                .apellido2(dtocliente.getApellido2())

                .telefono(dtocliente.getTelefono())
                .direccion(dtocliente.getDireccion())
                .build();
    }
    @PutMapping("/cliente")
    public Dtoclientes update(@RequestBody Dtoclientes dtocliente){
        Beanclientes clienteupdate = clienteService.save(dtocliente);
        return dtocliente.builder()
                .id_cliente(dtocliente.getId_cliente())
                .nombre(dtocliente.getNombre())
                .apellido(dtocliente.getApellido())
                .apellido2(dtocliente.getApellido2())

                .telefono(dtocliente.getTelefono())
                .direccion(dtocliente.getDireccion())
                .build();
    }
    @GetMapping("/cliente/{id}")
    public Beanclientes showById(@PathVariable Integer id){
        try{
            return clienteService.findById(id);
        } catch (DataAccessException dae){
            throw new RuntimeException("error en la base de datos", dae);
        } catch (Exception ex){
            throw new RuntimeException("error no  se pudo onbtener la persona", ex);
        }}
    @GetMapping("/cliente")
    public List<Beanclientes> findAll(){
        try{
            return clienteService.findAll();
        } catch (DataAccessException dae){
            throw new RuntimeException("error en la base de datos", dae);
        } catch (Exception ex){
            throw new RuntimeException("error no se pudo obtener la persona", ex);
        }

    }
    @DeleteMapping("/cliente/{id}")
    public ResponseEntity<?> delete(@PathVariable Integer id){
        Map<String, Object> response = new HashMap<>();
        try{
            Beanclientes user = clienteService.findById(id);
            clienteService.delete(user);
            return new ResponseEntity<>(user, HttpStatus.OK);
        } catch (DataAccessException ex){
            response.put("mensaje", ex.getMessage());

            response.put("Persona", null);
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }}
