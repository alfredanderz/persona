package edu.mx.utez.examenrecuperacion;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExamenrecuperacionApplicationTests {

	@Test
	void contextLoads() {
	}

}
